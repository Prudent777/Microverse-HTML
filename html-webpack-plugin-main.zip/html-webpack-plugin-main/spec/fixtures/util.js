'use strict';

require('./common');
document.body.innerHTML = document.body.innerHTML + '<p>util.js</p>';
