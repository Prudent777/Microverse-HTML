'use strict';

module.exports = 'common';
