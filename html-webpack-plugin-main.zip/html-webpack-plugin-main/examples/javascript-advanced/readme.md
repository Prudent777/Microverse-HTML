# isomorphic javascript-advanced example

This example is similar to the javascript example however it allows takes
parameters from the config and works asynchronously