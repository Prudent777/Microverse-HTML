require('./main.css');
var h1 = document.createElement('h1');
h1.innerHTML = 'a!';
document.body.appendChild(h1);
