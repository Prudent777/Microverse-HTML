var h1 = document.createElement('h1');
h1.innerHTML = 'd!';
document.body.appendChild(h1);
