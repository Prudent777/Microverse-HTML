'use strict';
require('./main.css');

console.log('Hello World');
