module.exports = function concat (a, b) {
  return String(a) + String(b);
};
