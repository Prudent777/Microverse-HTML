# isomorphic javascript example

This example shows how to generate a template on the fly using javascript.

The best way to debug the compilation result is `devTool:eval`